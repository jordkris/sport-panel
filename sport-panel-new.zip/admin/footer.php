 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b></b> 
    </div>
    <strong>Copyright &copy; 2019 </strong>  
    
  </footer>
   <div class="control-sidebar-bg"></div>