<?php
$title_header = "Upload";
$page_content = 'mastercontent.php';
$content_inside = 'upload.php';
include('master.php'); 
?>

