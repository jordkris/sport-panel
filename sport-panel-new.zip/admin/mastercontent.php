 
 
<section class="content">
 <div class="row">
	<div class="col-xs-12">
	  <div class="box">
	   
		<!-- /.box-header -->
		<?php include($content_inside);?>
	   
			
		 
	 </div>
	</div>
 </div>
</section>
