<?php
$title_header = "Dashboard";
$page_content = 'dashboard.php';
include('master.php');
?>