<?php
$title_header = "Config";
$page_content = 'mastercontent.php';
$content_inside = 'frontconfig.php';
include('master.php'); 
?>

