  <li class="header">MAIN NAVIGATION</li>
        <li><a href="index.php"><i class="fa fa-home"></i> <span>Home</span></a></li> 
        
	 
        <li><a href="image.php"><i class="fa fa-image"></i> <span>Upload Image</span></a></li> 
		<li><a href="front.php"><i class="fa fa-edit"></i> <span>Config</span></a></li> 
		 
		 