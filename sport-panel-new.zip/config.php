<?php 
error_reporting(E_ALL ^ E_NOTICE);
require_once('input/function.php');
$meta_title  = 'Full Movie Online';
$affliasi    = '//look.opskln.com/offer?prod=21&ref=5184914';
$site_url    = '//localhost/website/sport-panel';
$displayHistat = '4271945';
$match='Full Movie Online';
$reff = '';
define('TOPPATH', $_SERVER['DOCUMENT_ROOT'] );
?> 