<?php require_once('config.php');?>
<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Contact Us | SPORTS | </title>
	<meta name="description" content="<?php echo '' . htmlspecialchars($_GET["match"]) . ''; ?> HD Stream Online 1080p"/>
	<meta name="keywords" content=""/>
	<link href="<?php echo $site_url;?>/img/favicon.png" rel=icon type="image/x-icon"/>
	<link rel="stylesheet" id="watch-oncas---pane" href="https://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="watch-oncas---awesome" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css" jtype="text/css" media="all">
   	<link rel="stylesheet" id="watch-oncas---ptsan" href="https://fonts.googleapis.com/css?family=PT+Sans" type="text/css" media="all">
	<link rel="stylesheet" id="watch-oncas---style" href="<?php echo $site_url;?>/css/style.css" type="text/css" media="all">

	<!--[if lt IE 9]>
	<script src="https://html5shiv.googlecode.com/svn/trunk/html5.js" type="text/javascript"></script>

	<![endif]-->
	
</head>

<body class="single solid wide relative aweon ctrldft watch-oncas-- backdrop oncas">
    
<div id="page" data-role="page">
    <div data-role="panel" id="myPanel">
    	<ul class="PanelMenu">
        	<li><a href="<?php echo $site_url;?>" data-ajax="false"><i class="fa fa-home" title="Home"></i> Homepage</a></li>
        	<li><a href="<?php echo $site_url;?>/register.php" data-ajax="false"><i class="fa fa-user"></i> Login / Regsiter</a></li>
        	<li><a href="<?php echo $site_url;?>/soccer.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>SOCCER</a></li
        	<li><a href="<?php echo $site_url;?>/nba.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>NBA</a></li>
        	<li><a href="<?php echo $site_url;?>/nfl.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>NFL</a></li>
        	<li><a href="<?php echo $site_url;?>/ncaaf.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>NCAAF</a></li>
        	<li><a href="<?php echo $site_url;?>/rugby.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>RUGBY</a></li>
        	<li><a href="<?php echo $site_url;?>/mma.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>MMA</a></li>
        	<li><a href="<?php echo $site_url;?>/mlb.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>MLB</a></li>
        	<li><a href="<?php echo $site_url;?>/boxing.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>BOXING</a></li>
        	<li><a href="<?php echo $site_url;?>/f1.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>F1</a></li>
        	<li><a href="<?php echo $site_url;?>/motogp.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>MOTOGP</a></li>
        </ul>
    </div>
    
    <div class="">
        <header id="header" data-role="header">
        	<div class="header">
                <div class="wrapper">
                    <div class="inner-wrapper">
                        <a id="mob-bars" href="dmca.html#myPanel"><i class="fa fa-bars"></i></a>
                            <h2 id="site-title">
                                <a href="<?php echo $site_url;?>/index.php"><i class="fa fa-youtube-play"></i>SPORTS |  DMCA <font style="font-size:120%; color: #FF001A;"> </font></a>
                            </h2>
                        <div class="description">Movie Streaming Online 720p</div>
                    </div>
	            </div>
            </div>
           
<nav id="header-nav" role="navigation"><ul class="wrapper lsn">
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="/" data-ajax="false"><i class="fa fa-home"></i>HOME</a></li><li class="nav-pop"></i></a></li>
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="nba.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>NBA</a></li><li class="nav-pop"></i></a></li>
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="nfl.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>NFL</a></li><li class="nav-pop"></i></a></li>
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="rugby.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>RUGBY</a></li><li class="nav-pop"></i></a></li>
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="mma.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>MMA</a></li><li class="nav-pop"></i></a></li>
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="mlb.php" data-ajax="false"><i class="fa fa-play-circle-o"></i>MLB</a></li><li class="nav-pop"></i></a></li>
<li class="nav-now"></i></a></li><li class="nav-reg" ><a href="register.php" data-ajax="false"><i class="fa fa-user"></i>Sign Up</a></li><li class="nav-pop"></i></a></li>
</ul></nav>  
            
            
        </header>

<div id="primary" class="content" data-role="main">
	<div id="content">
		<article class="navi" id="contact">
	<div class="wrapper">
		<header class="page-header">
		    <p></p>
		    <p></p>
			<h1 class="page-title">Contact Us</h1>
		</header>
		<div class="entry-content">
        <p>If you want to remove a television channel from <?php echo $_SERVER['HTTP_HOST']; ?> please read our DMCA Policy.</p>
        <p><b>Email:</b> report.a.dmca@gmail.com</p>
		<p></p>	
		<p></p>		
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		<p></p>
		</div>
	</div>
</article>	</div>
</div>
    <div class="clear"></div><footer background="https://upload.wikimedia.org/wikipedia/commons/a/a7/Future_earth.jpg" data-role="footer">
    <div class="credit">
        <div class="wrapper">
            <marquee><font color="white"> Copyright &copy; <?php echo date("Y"); ?> <a href="" data-ajax="false">SPORTS |  <?php echo $meta_title;?></a> - All rights reserved.</font></marquee> 
        </div>	
    </div>
    <div class="clear"></div><div class="clear"></div>
    <nav id="footer-nav" role="navigation">
        <ul class="wrapper lsn">
            <li><a href="dmca.php">DMCA</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>						
</footer>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js" defer></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js" defer></script>
<script type="text/javascript" src="https://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js" defer></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" defer></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.cycle2/20140415/jquery.cycle2.min.js" defer></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.cycle2/20140415/jquery.cycle2.tile.min.js" defer></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.33/jquery.colorbox-min.js" defer></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/screenfull.js/1.0.4/screenfull.min.js" defer></script>
<script type="text/javascript" src="<?php echo $site_url;?>/js/scripts.js" defer></script>
	<?php include('histats.php');?>
</body>
</html>